import { SignMethod } from "../common/interface";
export declare class SignDTO {
    appkey: string;
    signSecret: string;
    method: string;
    signMethod: SignMethod;
    timestamp: number;
    version: number;
    accessToken: string;
    param: string;
}
