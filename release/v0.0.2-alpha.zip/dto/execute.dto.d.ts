import { Method } from "../common/interface";
export declare class ExecuteBaseDTO<T> {
    readonly api: T;
    readonly method?: Method;
    readonly version?: number;
}
