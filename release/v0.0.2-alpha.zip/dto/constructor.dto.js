'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var createClass = require('../node_modules/@babel/runtime/helpers/esm/createClass.js');
var classCallCheck = require('../node_modules/@babel/runtime/helpers/esm/classCallCheck.js');
var tslib_es6 = require('../node_modules/tslib/tslib.es6.js');
var index = require('../common/interface/index.js');
var index$1 = require('../common/regExp/index.js');
var validate_check_decorator = require('../decorator/validate.check.decorator.js');
var IsNotEmpty = require('../node_modules/class-validator/esm5/decorator/common/IsNotEmpty.js');
var IsString = require('../node_modules/class-validator/esm5/decorator/typechecker/IsString.js');
var Matches = require('../node_modules/class-validator/esm5/decorator/string/Matches.js');
var IsOptional = require('../node_modules/class-validator/esm5/decorator/common/IsOptional.js');

var ClientConstructorDTO = /*#__PURE__*/createClass["default"](function ClientConstructorDTO() {
  classCallCheck["default"](this, ClientConstructorDTO);
});

tslib_es6.__decorate([IsNotEmpty.IsNotEmpty(), IsString.IsString(), tslib_es6.__metadata("design:type", String)], ClientConstructorDTO.prototype, "appKey", void 0);

tslib_es6.__decorate([IsNotEmpty.IsNotEmpty(), IsString.IsString(), tslib_es6.__metadata("design:type", String)], ClientConstructorDTO.prototype, "signSecret", void 0);

tslib_es6.__decorate([Matches.Matches(index$1.urlReg, {
  message: 'url格式不正确，请输入正确的开放平台域名'
}), IsString.IsString(), IsOptional.IsOptional(), tslib_es6.__metadata("design:type", String)], ClientConstructorDTO.prototype, "url", void 0);

tslib_es6.__decorate([validate_check_decorator.EqualsList([index.SignMethod.HMAC_SHA256, index.SignMethod.MD5]), IsOptional.IsOptional(), tslib_es6.__metadata("design:type", String)], ClientConstructorDTO.prototype, "signMethod", void 0);

tslib_es6.__decorate([IsNotEmpty.IsNotEmpty(), IsString.IsString(), tslib_es6.__metadata("design:type", String)], ClientConstructorDTO.prototype, "accessToken", void 0);

exports.ClientConstructorDTO = ClientConstructorDTO;
