'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var createClass = require('../node_modules/@babel/runtime/helpers/esm/createClass.js');
var classCallCheck = require('../node_modules/@babel/runtime/helpers/esm/classCallCheck.js');
var tslib_es6 = require('../node_modules/tslib/tslib.es6.js');
var index = require('../common/interface/index.js');
var validate_check_decorator = require('../decorator/validate.check.decorator.js');
var IsString = require('../node_modules/class-validator/esm5/decorator/typechecker/IsString.js');
var IsNotEmpty = require('../node_modules/class-validator/esm5/decorator/common/IsNotEmpty.js');
var IsNumber = require('../node_modules/class-validator/esm5/decorator/typechecker/IsNumber.js');

var SignDTO = /*#__PURE__*/createClass["default"](function SignDTO() {
  classCallCheck["default"](this, SignDTO);
});

tslib_es6.__decorate([IsString.IsString(), IsNotEmpty.IsNotEmpty(), tslib_es6.__metadata("design:type", String)], SignDTO.prototype, "appkey", void 0);

tslib_es6.__decorate([IsString.IsString(), IsNotEmpty.IsNotEmpty(), tslib_es6.__metadata("design:type", String)], SignDTO.prototype, "signSecret", void 0);

tslib_es6.__decorate([IsString.IsString(), IsNotEmpty.IsNotEmpty(), tslib_es6.__metadata("design:type", String)], SignDTO.prototype, "method", void 0);

tslib_es6.__decorate([validate_check_decorator.EqualsList([index.SignMethod.HMAC_SHA256, index.SignMethod.MD5]), IsNotEmpty.IsNotEmpty(), tslib_es6.__metadata("design:type", String)], SignDTO.prototype, "signMethod", void 0);

tslib_es6.__decorate([IsNumber.IsNumber(), IsNotEmpty.IsNotEmpty(), tslib_es6.__metadata("design:type", Number)], SignDTO.prototype, "timestamp", void 0);

tslib_es6.__decorate([IsNumber.IsNumber(), IsNotEmpty.IsNotEmpty(), tslib_es6.__metadata("design:type", Number)], SignDTO.prototype, "version", void 0);

tslib_es6.__decorate([IsString.IsString(), IsNotEmpty.IsNotEmpty(), tslib_es6.__metadata("design:type", String)], SignDTO.prototype, "accessToken", void 0);

tslib_es6.__decorate([IsString.IsString(), IsNotEmpty.IsNotEmpty(), tslib_es6.__metadata("design:type", String)], SignDTO.prototype, "param", void 0);

exports.SignDTO = SignDTO;
