import { SignMethod } from "../common/interface";
export declare class ClientConstructorDTO {
    readonly appKey: string;
    readonly signSecret: string;
    readonly url?: string;
    readonly signMethod?: SignMethod;
    readonly accessToken: string;
}
