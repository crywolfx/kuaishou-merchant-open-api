'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var createClass = require('../node_modules/@babel/runtime/helpers/esm/createClass.js');
var classCallCheck = require('../node_modules/@babel/runtime/helpers/esm/classCallCheck.js');
var tslib_es6 = require('../node_modules/tslib/tslib.es6.js');
var validate_check_decorator = require('../decorator/validate.check.decorator.js');
var IsNumber = require('../node_modules/class-validator/esm5/decorator/typechecker/IsNumber.js');
var IsString = require('../node_modules/class-validator/esm5/decorator/typechecker/IsString.js');
var IsOptional = require('../node_modules/class-validator/esm5/decorator/common/IsOptional.js');

var ExecuteBaseDTO = /*#__PURE__*/createClass["default"](function ExecuteBaseDTO() {
  classCallCheck["default"](this, ExecuteBaseDTO);
});

tslib_es6.__decorate([IsString.IsString(), tslib_es6.__metadata("design:type", Object)], ExecuteBaseDTO.prototype, "api", void 0);

tslib_es6.__decorate([validate_check_decorator.EqualsList(['GET', 'POST']), IsOptional.IsOptional(), tslib_es6.__metadata("design:type", String)], ExecuteBaseDTO.prototype, "method", void 0);

tslib_es6.__decorate([IsNumber.IsNumber(), IsOptional.IsOptional(), tslib_es6.__metadata("design:type", Number)], ExecuteBaseDTO.prototype, "version", void 0);

exports.ExecuteBaseDTO = ExecuteBaseDTO;
