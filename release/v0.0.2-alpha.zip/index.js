'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var main = require('./main.js');
var index = require('./common/interface/index.js');



exports["default"] = main["default"];
Object.defineProperty(exports, 'SignMethod', {
	enumerable: true,
	get: function () { return index.SignMethod; }
});
