export declare const signMethods: {
    HMAC_SHA256: (message: string, key?: string) => string;
    MD5: (message: string) => string;
};
