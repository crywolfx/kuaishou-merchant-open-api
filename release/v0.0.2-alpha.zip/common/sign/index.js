'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var defineProperty = require('../../node_modules/@babel/runtime/helpers/esm/defineProperty.js');
var hmacSha256 = require('../../node_modules/crypto-js/hmac-sha256.js');
var md5 = require('../../node_modules/crypto-js/md5.js');
var encBase64 = require('../../node_modules/crypto-js/enc-base64.js');
var index = require('../interface/index.js');

var _signMethods;
var signMethods = (_signMethods = {}, defineProperty["default"](_signMethods, index.SignMethod.HMAC_SHA256, function (message) {
  var key = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';
  return encBase64["default"].stringify(hmacSha256["default"](message, key));
}), defineProperty["default"](_signMethods, index.SignMethod.MD5, function (message) {
  return md5["default"](message).toString();
}), _signMethods);

exports.signMethods = signMethods;
