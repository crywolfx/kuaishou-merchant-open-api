export declare const urlReg: RegExp;
