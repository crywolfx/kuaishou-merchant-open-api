'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var urlReg = /^((([hH][tT]|)[tT][pP][sS]?):\/\/)?[\w-]+(\.[\w-]+)+([\w.,@?^=%&:/~+#-]*[\w@?^=%&/~+#-])?$/;

exports.urlReg = urlReg;
