declare const service: import("axios").AxiosInstance;
export default service;
