'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var index = require('../../node_modules/axios/index.js');

var service = index["default"].create({
  headers: {
    'request-source': 'kuaishou-merchant-node-open-api'
  }
});
service.interceptors.response.use(function (res) {
  return res.data;
}, function (res) {
  var _a;

  return (_a = res === null || res === void 0 ? void 0 : res.response) === null || _a === void 0 ? void 0 : _a.data;
});

exports["default"] = service;
