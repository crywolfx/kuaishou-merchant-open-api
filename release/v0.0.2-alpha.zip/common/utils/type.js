'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function isFunction(val) {
  return Object.prototype.toString.call(val) === '[object Function]';
}
function isObject(val) {
  return Object.prototype.toString.call(val) === '[object Object]';
}
function isUndefined(val) {
  return val === undefined;
}
function objectKeys(object) {
  return Object.keys(object);
}

exports.isFunction = isFunction;
exports.isObject = isObject;
exports.isUndefined = isUndefined;
exports.objectKeys = objectKeys;
