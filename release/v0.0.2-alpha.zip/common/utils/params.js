'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var form_data = require('../../node_modules/form-data/lib/form_data.js');
var type = require('./type.js');
var require$$0 = require('stream');

var sortParams = function sortParams(params) {
  if (!params || !type.isObject(params)) return {};
  var keys = Object.keys(params);
  return keys.sort().reduce(function (pre, key) {
    pre[key] = params[key];
    return pre;
  }, {});
};
var pathReplace = function pathReplace(string) {
  return string.replace(/\./g, '/');
};
var formatParams = function formatParams(params) {
  if (!type.isObject(params)) return params;
  return Object.keys(params).reduce(function (pre, key) {
    var value = params[key];

    if (value instanceof Buffer || value instanceof require$$0.Stream) {
      pre.file[key] = value;
    } else {
      pre.params[key] = value;
    }

    return pre;
  }, {
    params: {},
    file: {}
  });
};
var params2FormData = function params2FormData(params) {
  if (!type.isObject(params)) return params;
  return Object.keys(params).reduce(function (pre, key) {
    pre.append(key, params[key]);
    return pre;
  }, new form_data["default"]());
};

exports.formatParams = formatParams;
exports.params2FormData = params2FormData;
exports.pathReplace = pathReplace;
exports.sortParams = sortParams;
