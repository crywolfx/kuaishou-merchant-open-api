import { ValidationError } from "class-validator";
export declare const formatValidationError: (error: ValidationError[]) => string;
