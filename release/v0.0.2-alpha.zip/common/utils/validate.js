'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var index = require('../../node_modules/lodash.flatten/index.js');

var formatValidationError = function formatValidationError(error) {
  return index["default"](error.map(function (errorItem) {
    return Object.values(errorItem.constraints);
  })).join(';');
};

exports.formatValidationError = formatValidationError;
