'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

exports.SignMethod = void 0;

(function (SignMethod) {
  SignMethod["HMAC_SHA256"] = "HMAC_SHA256";
  SignMethod["MD5"] = "MD5";
})(exports.SignMethod || (exports.SignMethod = {}));
