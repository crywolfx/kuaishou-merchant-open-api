export * from './api.declaration';
export declare enum SignMethod {
    HMAC_SHA256 = "HMAC_SHA256",
    MD5 = "MD5"
}
export interface CommonParams {
    appKey: string;
    signSecret: string;
    url?: string;
    signMethod?: SignMethod;
    accessToken: string;
}
export interface SignParams {
    appkey: string;
    signSecret: string;
    method: string;
    signMethod: SignMethod;
    timestamp: number;
    version: number;
    accessToken: string;
    param: string;
}
export declare type Method = 'GET' | 'POST';
export interface ApiResponse<T = any> {
    result: number;
    error_msg: string;
    requestId: string;
    data: T;
}
