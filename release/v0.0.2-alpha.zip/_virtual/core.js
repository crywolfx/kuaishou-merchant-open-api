'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var core = {exports: {}};

exports.core = core;
