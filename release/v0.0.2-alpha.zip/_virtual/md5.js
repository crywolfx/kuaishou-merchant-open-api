'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var md5 = {exports: {}};

exports.md5 = md5;
