'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var assertString = {exports: {}};

exports.assertString = assertString;
