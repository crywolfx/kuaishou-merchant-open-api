'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var axios = {exports: {}};

exports.axios = axios;
