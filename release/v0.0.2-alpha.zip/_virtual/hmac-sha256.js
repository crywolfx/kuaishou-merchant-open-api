'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var hmacSha256 = {exports: {}};

exports.hmacSha256 = hmacSha256;
