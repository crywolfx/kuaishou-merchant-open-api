'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var followRedirects = {exports: {}};

exports.followRedirects = followRedirects;
