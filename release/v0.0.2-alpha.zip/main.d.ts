import { ClientConstructorDTO } from "./dto/constructor.dto";
import { ApiResponse, SignMethod, ApiDeclaration } from "./common/interface";
import { ExecuteBaseDTO } from "./dto/execute.dto";
import { SignDTO } from "./dto/sign.dto";
declare class KsMerchantClient {
    appKey: string;
    signSecret: string;
    url: string;
    signMethod: SignMethod;
    accessToken: string;
    constructor(commonParams: ClientConstructorDTO);
    generateApiUrl(api: string): string;
    generateSign({ appkey, signSecret, method, signMethod, timestamp, accessToken, version, param }: SignDTO): string;
    execute<T extends keyof ApiDeclaration>({ api, method, version }: ExecuteBaseDTO<T>, orgParams?: ApiDeclaration[T]['request']): Promise<ApiResponse<ApiDeclaration[T]["response"]>>;
}
export default KsMerchantClient;
