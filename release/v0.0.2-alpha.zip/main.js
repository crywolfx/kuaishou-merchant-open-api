'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var classCallCheck = require('./node_modules/@babel/runtime/helpers/esm/classCallCheck.js');
var createClass = require('./node_modules/@babel/runtime/helpers/esm/createClass.js');
var tslib_es6 = require('./node_modules/tslib/tslib.es6.js');
var index = require('./common/sign/index.js');
var type = require('./common/utils/type.js');
var params = require('./common/utils/params.js');
var index$1 = require('./common/request/index.js');
var constructor_dto = require('./dto/constructor.dto.js');
var index$2 = require('./common/interface/index.js');
var validate_decorator = require('./decorator/validate.decorator.js');
var execute_dto = require('./dto/execute.dto.js');
var sign_dto = require('./dto/sign.dto.js');

var KsMerchantClient = /*#__PURE__*/function () {
  function KsMerchantClient(commonParams) {
    classCallCheck["default"](this, KsMerchantClient);

    this.appKey = commonParams === null || commonParams === void 0 ? void 0 : commonParams.appKey;
    this.signSecret = commonParams === null || commonParams === void 0 ? void 0 : commonParams.signSecret;
    this.signMethod = (commonParams === null || commonParams === void 0 ? void 0 : commonParams.signMethod) || index$2.SignMethod.MD5;
    this.url = (commonParams === null || commonParams === void 0 ? void 0 : commonParams.url) || 'https://openapi.kwaixiaodian.com';
    this.accessToken = commonParams === null || commonParams === void 0 ? void 0 : commonParams.accessToken;
  }

  createClass["default"](KsMerchantClient, [{
    key: "generateApiUrl",
    value: function generateApiUrl(api) {
      var url = new URL(this.url);
      url.pathname = params.pathReplace(api);
      return url.toString();
    }
  }, {
    key: "generateSign",
    value: function generateSign(_ref) {
      var appkey = _ref.appkey,
          signSecret = _ref.signSecret,
          method = _ref.method,
          signMethod = _ref.signMethod,
          timestamp = _ref.timestamp,
          accessToken = _ref.accessToken,
          version = _ref.version,
          param = _ref.param;
      var data = "access_token=".concat(accessToken, "&appkey=").concat(appkey, "&method=").concat(method, "&param=").concat(param, "&signMethod=").concat(signMethod, "&timestamp=").concat(timestamp, "&version=").concat(version, "&signSecret=").concat(signSecret);
      var signMethodFunction = index.signMethods[signMethod];
      if (!type.isFunction(signMethodFunction)) throw Error("signMethod [".concat(signMethod, "] is not support"));
      return index.signMethods[signMethod](data, signSecret);
    }
  }, {
    key: "execute",
    value: function execute(_ref2, orgParams) {
      var api = _ref2.api,
          method = _ref2.method,
          _ref2$version = _ref2.version,
          version = _ref2$version === void 0 ? 1 : _ref2$version;

      var _ref3 = params.formatParams(orgParams) || {},
          _ref3$params = _ref3.params,
          params$1 = _ref3$params === void 0 ? {} : _ref3$params,
          _ref3$file = _ref3.file,
          file = _ref3$file === void 0 ? {} : _ref3$file;

      var isUpload = Object.keys(file).length > 0;
      method = method || (isUpload ? 'POST' : 'GET');
      var sortedParams = params.sortParams(params$1);
      var paramsString = JSON.stringify(sortedParams);
      var requestUrl = this.generateApiUrl(api);
      var timestamp = +new Date();
      var sign = this.generateSign({
        appkey: this.appKey,
        signSecret: this.signSecret,
        method: api,
        signMethod: this.signMethod,
        timestamp: timestamp,
        accessToken: this.accessToken,
        version: version,
        param: paramsString
      });

      var _data;

      var _params = {};
      var header = {};
      var baseParams = {
        appkey: this.appKey,
        version: version,
        access_token: this.accessToken,
        signMethod: this.signMethod,
        timestamp: timestamp,
        sign: sign,
        method: api
      };

      if (method === 'POST') {
        if (isUpload) {
          _data = params.params2FormData(Object.assign(Object.assign({
            param: paramsString
          }, file), baseParams));
          header = Object.assign({}, _data.getHeaders());
        } else {
          _data = new URLSearchParams(Object.assign({
            param: paramsString
          }, baseParams)).toString();
        }
      } else {
        _params = Object.assign({
          param: paramsString
        }, baseParams);
      }

      return index$1["default"].request({
        url: requestUrl,
        method: method,
        params: _params,
        data: _data,
        headers: header
      });
    }
  }]);

  return KsMerchantClient;
}();

tslib_es6.__decorate([validate_decorator.Validate(), tslib_es6.__param(0, validate_decorator.Required), tslib_es6.__metadata("design:type", Function), tslib_es6.__metadata("design:paramtypes", [sign_dto.SignDTO]), tslib_es6.__metadata("design:returntype", void 0)], KsMerchantClient.prototype, "generateSign", null);

tslib_es6.__decorate([validate_decorator.Validate(), tslib_es6.__param(0, validate_decorator.Required), tslib_es6.__metadata("design:type", Function), tslib_es6.__metadata("design:paramtypes", [execute_dto.ExecuteBaseDTO, Object]), tslib_es6.__metadata("design:returntype", void 0)], KsMerchantClient.prototype, "execute", null);

KsMerchantClient = tslib_es6.__decorate([validate_decorator.ValidateClass(), tslib_es6.__param(0, validate_decorator.Required), tslib_es6.__metadata("design:paramtypes", [constructor_dto.ClientConstructorDTO])], KsMerchantClient);
var KsMerchantClient$1 = KsMerchantClient;
var client = new KsMerchantClient({
  appKey: 'ks683702719562282620',
  signSecret: '7482bac6555ee7a3184bcc48f4ef05cd',
  url: 'https://gw-merchant-staging.test.gifshow.com/',
  accessToken: 'ChFvYXV0aC5hY2Nlc3NUb2tlbhJQvR5J47YI8jOtjpJ45Fxr581ivbbEMwD_6p9LyetQTrV__nn7twczdU26Nj0_Vg1yJNikxGwybVJtopFWoIDWLY1TA-n-SWqpAPTbhN5OiHoaEmGCxNN-dgGEGt2EnlHtDE6c8CIg5OuMg-N5AE3gsKKM4oNegNc7kqkhGIIQggL5fl0hGc0oDzAB'
});
client.execute({
  api: 'open.item.detail.images.update'
}, {
  kwaiItemId: 123
}).then(function (res) {
  console.log(res);
});

exports["default"] = KsMerchantClient$1;
