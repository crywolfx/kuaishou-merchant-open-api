import 'reflect-metadata';
export declare function Required(target: any, propertyKey: string | symbol, parameterIndex: number): void;
export declare const throwError: (param: string, index: number, message?: string) => never;
export declare const handlerValidate: (params: any[], requiredParameters: number[], designParamTypes: any) => void;
export declare function ValidateClass(): <T extends new (...args: any[]) => any>(BaseClass: T) => {
    new (...params: any[]): {
        [x: string]: any;
    };
} & T;
export declare function Validate(): (target: any, propertyKey: string | symbol, descriptor: PropertyDescriptor) => void;
