'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var registerDecorator = require('../node_modules/class-validator/esm5/register-decorator.js');
var ValidateBy = require('../node_modules/class-validator/esm5/decorator/common/ValidateBy.js');

function EqualsList(comparison, validationOptions) {
  return function (object, propertyName) {
    registerDecorator.registerDecorator({
      name: 'EqualsList',
      target: object.constructor,
      propertyName: propertyName,
      options: validationOptions,
      validator: {
        validate: function validate(value) {
          return comparison.includes(value);
        },
        defaultMessage: ValidateBy.buildMessage(function (eachPrefix) {
          return eachPrefix + '$property must be ' + comparison.join(',');
        }, validationOptions)
      }
    });
  };
}

exports.EqualsList = EqualsList;
