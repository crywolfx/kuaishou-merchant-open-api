import { ValidationOptions } from "class-validator";
export declare function EqualsList(comparison: any[], validationOptions?: ValidationOptions): (object: unknown, propertyName: string) => void;
