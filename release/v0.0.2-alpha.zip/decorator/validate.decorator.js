'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var createClass = require('../node_modules/@babel/runtime/helpers/esm/createClass.js');
var classCallCheck = require('../node_modules/@babel/runtime/helpers/esm/classCallCheck.js');
var inherits = require('../node_modules/@babel/runtime/helpers/esm/inherits.js');
var possibleConstructorReturn = require('../node_modules/@babel/runtime/helpers/esm/possibleConstructorReturn.js');
var getPrototypeOf = require('../node_modules/@babel/runtime/helpers/esm/getPrototypeOf.js');
require('../node_modules/reflect-metadata/Reflect.js');
var type = require('../common/utils/type.js');
require('../node_modules/form-data/lib/form_data.js');
require('stream');
var validate = require('../common/utils/validate.js');
var index = require('../node_modules/class-validator/esm5/index.js');

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = getPrototypeOf["default"](Derived), result; if (hasNativeReflectConstruct) { var NewTarget = getPrototypeOf["default"](this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return possibleConstructorReturn["default"](this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }

function _createForOfIteratorHelper(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }
var requiredMetadataKey = Symbol("required");
function Required(target, propertyKey, parameterIndex) {
  var existingRequiredParameters = Reflect.getOwnMetadata(requiredMetadataKey, target, propertyKey) || [];
  existingRequiredParameters.push(parameterIndex);
  Reflect.defineMetadata(requiredMetadataKey, existingRequiredParameters, target, propertyKey);
}
var throwError = function throwError(param, index, message) {
  var msg = "Failed for validating parameter: ".concat(param, " of the index: ").concat(index, " ").concat(message ? ', ' + message : '');
  throw Error(msg);
};
var handlerValidate = function handlerValidate() {
  var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
  var requiredParameters = arguments.length > 1 ? arguments[1] : undefined;
  var designParamTypes = arguments.length > 2 ? arguments[2] : undefined;

  if (requiredParameters === null || requiredParameters === void 0 ? void 0 : requiredParameters.length) {
    var _iterator = _createForOfIteratorHelper(requiredParameters),
        _step;

    try {
      var _loop = function _loop() {
        var index$1 = _step.value;
        var paramType = designParamTypes[index$1];
        var param = params[index$1];
        if (type.isUndefined(param)) throwError(param, index$1);
        var validateResult = param.constructor === paramType || param instanceof paramType || param.constructor.__proto__ instanceof paramType;

        if (!validateResult && type.isObject(param)) {
          try {
            var validateInstance = new paramType();
            type.objectKeys(param).forEach(function (key) {
              validateInstance[key] = param[key];
            });
            var errorList = index.validateSync(validateInstance);

            if (errorList === null || errorList === void 0 ? void 0 : errorList.length) {
              throw Error(validate.formatValidationError(errorList));
            }
          } catch (error) {
            throwError(JSON.stringify(param), index$1, error === null || error === void 0 ? void 0 : error.message);
          }
        }
      };

      for (_iterator.s(); !(_step = _iterator.n()).done;) {
        _loop();
      }
    } catch (err) {
      _iterator.e(err);
    } finally {
      _iterator.f();
    }
  }
};
function ValidateClass() {
  return function (BaseClass) {
    return /*#__PURE__*/function (_BaseClass) {
      inherits["default"](_class, _BaseClass);

      var _super = _createSuper(_class);

      function _class() {
        var _this;

        classCallCheck["default"](this, _class);

        for (var _len = arguments.length, params = new Array(_len), _key = 0; _key < _len; _key++) {
          params[_key] = arguments[_key];
        }

        _this = _super.call.apply(_super, [this].concat(params));
        var requiredParameters = Reflect.getOwnMetadata(requiredMetadataKey, BaseClass);
        var designParamTypes = Reflect.getMetadata('design:paramtypes', BaseClass);
        handlerValidate(params, requiredParameters, designParamTypes);
        return _this;
      }

      return createClass["default"](_class);
    }(BaseClass);
  };
}
function Validate() {
  return function (target, propertyKey, descriptor) {
    var original = descriptor.value;
    var requiredParameters = Reflect.getOwnMetadata(requiredMetadataKey, target, propertyKey);
    var designParamTypes = Reflect.getMetadata('design:paramtypes', target, propertyKey);

    descriptor.value = function () {
      for (var _len2 = arguments.length, params = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
        params[_key2] = arguments[_key2];
      }

      handlerValidate(params, requiredParameters, designParamTypes);
      return original.call.apply(original, [this].concat(params));
    };
  };
}

exports.Required = Required;
exports.Validate = Validate;
exports.ValidateClass = ValidateClass;
exports.handlerValidate = handlerValidate;
exports.throwError = throwError;
